-- সব পুরানো অ্যাডমিন ডিলিট করুন
DELETE FROM users WHERE role = 'super_admin' OR is_admin = 1 OR is_super_admin = 1;

-- আপনার নতুন অ্যাডমিন অ্যাকাউন্ট তৈরি করুন
INSERT INTO users (
    full_name,
    username, 
    email, 
    password_hash, 
    coins, 
    role, 
    status, 
    is_admin, 
    is_super_admin, 
    admin_permissions,
    created_at
) VALUES (
    'SHOFI',
    'shofi',
    'kasici9854@cadebek.com',
    'pbkdf2:sha256:1000000$THqHLDryAf0nXXDL$c9a5fde0dbc60a0f371d27f04941130b5adba38fe6329dcfacf25e1853c7e6a9',
    1000,
    'super_admin',
    'active',
    1,
    1,
    'manage_users,manage_coins,manage_files,manage_settings,manage_announcements,manage_broadcasts,view_logs',
    CURRENT_TIMESTAMP
);

-- কনফর্মেশন চেক করুন
SELECT id, full_name, username, email, role FROM users WHERE username = 'shofi';